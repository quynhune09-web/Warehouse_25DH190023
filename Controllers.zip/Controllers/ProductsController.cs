﻿using System;
using System.Linq;
using System.Web.Mvc;
using Warehouse_25DH190023.Models;

namespace Warehouse_25DH190023.Controllers
{
    public class ProductsController : Controller
    {
        // Khởi tạo thực thể Entity Framework kết nối CSDL
        private Warehouse_25DH190023Entities db = new Warehouse_25DH190023Entities();

        // CÂU 2 & CÂU 3: HIỂN THỊ, LỌC VÀ SẮP XẾP TỒN KHO
        public ActionResult Index(string category, int? minQty, int? maxQty, string sortOrder)
        {
            var products = db.Products.AsQueryable();

            // Đổ danh sách danh mục ra Dropdown lọc
            ViewBag.Categories = db.Products.Select(p => p.Category).Distinct().ToList();

            // Xử lý logic lọc theo khoảng tồn kho (Từ số lượng - Đến số lượng)
            if (minQty.HasValue || maxQty.HasValue)
            {
                int min = minQty ?? 0;
                int max = maxQty ?? int.MaxValue;

                // Validate: Nếu Từ số lượng > Đến số lượng hoặc giá trị âm
                if (min < 0 || max < 0 || min > max)
                {
                    ViewBag.Error = "Lỗi: Khoảng số lượng không hợp lệ (Từ số lượng không được lớn hơn Đến số lượng và không được chứa số âm).";
                    products = products.Where(p => false); // Trả về danh sách rỗng khi sai điều kiện
                }
                else
                {
                    products = products.Where(p => p.Quantity >= min && p.Quantity <= max);
                }
            }

            // Kết hợp lọc theo danh mục (Category)
            if (!string.IsNullOrEmpty(category))
            {
                products = products.Where(p => p.Category == category);
            }

            // Sắp xếp Quantity tăng dần hoặc giảm dần bằng LINQ
            switch (sortOrder)
            {
                case "asc":
                    products = products.OrderBy(p => p.Quantity);
                    break;
                case "desc":
                    products = products.OrderByDescending(p => p.Quantity);
                    break;
                default:
                    products = products.OrderBy(p => p.ProductID);
                    break;
            }

            // Giữ lại giá trị người dùng đã chọn trên form
            ViewBag.CurrentCategory = category;
            ViewBag.CurrentMin = minQty;
            ViewBag.CurrentMax = maxQty;
            ViewBag.CurrentSort = sortOrder;

            return View(products.ToList());
        }

        // CÂU 2b: XÓA SẢN PHẨM HẾT HÀNG
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id)
        {
            // 1. Kiểm tra xem ProductID có tồn tại trong CSDL không
            var product = db.Products.Find(id);
            if (product == null)
            {
                TempData["Error"] = "Mã sản phẩm không tồn tại trong hệ thống.";
                return RedirectToAction("Index");
            }

            // 2. Nếu số lượng lớn hơn 0 thì từ chối xóa, giữ nguyên bản ghi
            if (product.Quantity > 0)
            {
                TempData["Error"] = "Từ chối xóa! Sản phẩm này vẫn còn hàng (Quantity > 0).";
                return RedirectToAction("Index");
            }

            // 3. Nếu Quantity == 0 thì tiến hành xóa khỏi Entity Framework
            db.Products.Remove(product);
            db.SaveChanges();
            TempData["Success"] = "Đã xóa thành công sản phẩm hết hàng.";
            return RedirectToAction("Index");
        }
        // ==========================================
        // CÂU 4: NHẬP KHO VÀ GHI NHẬN HÀNG HỎNG
        // ==========================================
        public ActionResult UpdateStock(int? id)
        {
            if (!id.HasValue)
            {
                TempData["Error"] = "Vui lòng chọn một sản phẩm cụ thể từ danh sách để cập nhật kho.";
                return RedirectToAction("Index");
            }

            var product = db.Products.Find(id.Value);
            if (product == null)
            {
                TempData["Error"] = "Mã sản phẩm không tồn tại trong hệ thống.";
                return RedirectToAction("Index");
            }
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateStock(int id, int amount, string updateType)
        {
            var product = db.Products.Find(id);
            if (product == null)
            {
                TempData["Error"] = "Mã sản phẩm không tồn tại trong hệ thống.";
                return RedirectToAction("Index");
            }

            if (amount <= 0)
            {
                ViewBag.Error = "Lỗi: Số lượng nhập kho hoặc hàng hỏng phải là số nguyên dương lớn hơn 0.";
                return View(product);
            }

            if (updateType == "Import")
            {
                product.Quantity += amount;
                TempData["Success"] = "Nhập kho thành công! Số lượng tồn đã được cộng thêm.";
            }
            else if (updateType == "Damage")
            {
                if (amount > product.Quantity)
                {
                    ViewBag.Error = "Lỗi: Số lượng hàng hỏng không được lớn hơn số lượng tồn kho hiện tại.";
                    return View(product);
                }
                product.Quantity -= amount;
                TempData["Success"] = "Ghi nhận hàng hỏng thành công! Số lượng tồn đã được trừ.";
            }

            db.SaveChanges();
            return RedirectToAction("Index");
        }

        // ==========================================
        // CÂU 5: ĐIỀU CHUYỂN HÀNG GIỮA HAI SẢN PHẨM
        // ==========================================
        public ActionResult Transfer()
        {
            ViewBag.Products = db.Products.ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Transfer(int fromProductId, int toProductId, int transferAmount)
        {
            ViewBag.Products = db.Products.ToList();

            if (transferAmount <= 0)
            {
                ViewBag.Error = "Lỗi: Số lượng điều chuyển phải là số nguyên dương lớn hơn 0.";
                return View();
            }

            if (fromProductId == toProductId)
            {
                ViewBag.Error = "Lỗi: Sản phẩm nguồn và sản phẩm đích không được trùng nhau.";
                return View();
            }

            using (var transaction = db.Database.BeginTransaction())
            {
                try
                {
                    var productA = db.Products.Find(fromProductId);
                    var productB = db.Products.Find(toProductId);

                    if (productA == null || productB == null)
                    {
                        ViewBag.Error = "Lỗi: Một trong hai sản phẩm không tồn tại trong hệ thống.";
                        return View();
                    }

                    if (productA.Category != productB.Category)
                    {
                        ViewBag.Error = "Từ chối điều chuyển! Hai sản phẩm phải thuộc cùng một danh mục (Category).";
                        return View();
                    }

                    if (productA.Quantity < transferAmount)
                    {
                        ViewBag.Error = "Từ chối điều chuyển! Sản phẩm nguồn không đủ số lượng tồn kho để chuyển.";
                        return View();
                    }

                    productA.Quantity -= transferAmount;
                    productB.Quantity += transferAmount;
                    db.SaveChanges();

                    transaction.Commit();
                    TempData["Success"] = "Điều chuyển hàng hóa thành công!";
                    return RedirectToAction("Index");
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    ViewBag.Error = "Đã xảy ra lỗi hệ thống, giao dịch điều chuyển đã bị hủy bỏ.";
                    return View();
                }
            }
        }

        // ==========================================
        // CÂU 6: THÊM SẢN PHẨM MỚI (CRUD CREATE)
        // ==========================================
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Product product)
        {
            if (string.IsNullOrWhiteSpace(product.ProductName))
            {
                ModelState.AddModelError("ProductName", "Lỗi: Tên sản phẩm không được để trống.");
            }
            if (string.IsNullOrWhiteSpace(product.Category))
            {
                ModelState.AddModelError("Category", "Lỗi: Danh mục không được để trống.");
            }
            if (product.Price <= 0)
            {
                ModelState.AddModelError("Price", "Lỗi: Giá sản phẩm phải lớn hơn 0.");
            }
            if (product.Quantity < 0)
            {
                ModelState.AddModelError("Quantity", "Lỗi: Số lượng tồn kho phải lớn hơn hoặc bằng 0.");
            }

            if (ModelState.IsValid)
            {
                db.Products.Add(product);
                db.SaveChanges();
                TempData["Success"] = "Thêm sản phẩm mới thành công!";
                return RedirectToAction("Index");
            }

            return View(product);
        }

        // ==========================================
        // CÂU 7: THỐNG KÊ TỒN KHO
        // ==========================================
        public ActionResult Statistics()
        {
            ViewBag.TotalProducts = db.Products.Count();
            ViewBag.TotalUnits = db.Products.Any() ? db.Products.Sum(p => p.Quantity) : 0;
            ViewBag.LowStockCount = db.Products.Count(p => p.Quantity >= 1 && p.Quantity <= 4);

            return View();
        }
    }
}